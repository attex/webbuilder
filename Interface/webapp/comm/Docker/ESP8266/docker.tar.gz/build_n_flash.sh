cd /build
make
make ESPPORT=/dev/ttyUSB0 flash
