sudo docker run --device /dev/ttyUSB0:/dev/ttyUSB0 -v /home/oke/Desktop/esp-open-sdk/examples/blinky/:/build img8
